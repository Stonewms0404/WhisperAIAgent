﻿ | FileName                  | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |---------------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | onnxruntime.dll           | Pass   | 8.83MB   | 105.48         | 1.88        | 0.45        | 103.14        | 0           | 
 | time_providers_shared.dll | Pass   | 12KB     | 84.83          | 0.91        | 0.43        | 82.49         | 0           | 
