Piper development has moved: https://github.com/OHF-Voice/piper1-gpl
This project (`piper-phonemize`) is no longer required, since `espeak-ng` is now embedded into the Piper Python wheel directly.
